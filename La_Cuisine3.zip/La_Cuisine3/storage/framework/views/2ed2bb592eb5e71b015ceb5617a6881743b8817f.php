<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <title>La Cuisine</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            box-sizing: border-box;
        }

        /* Style the body */
        body {
            font-family: 'Times New Roman', Times, serif;
            margin: 0;
        }

        /* Header/logo Title */
        .header {
            padding: 15px;
            text-align: center;
            background: #1abc9c;
            color: white;
        }

        /* Increase the font size of the heading */
        .header h1 {
            font-size: 80px;
            font-family: Snell Roundhand, cursive;
            font-variant: small-caps
        }

        /* Sticky navbar - toggles between relative and fixed, depending on the scroll position. It is positioned relative until a given offset position is met in the viewport - then it "sticks" in place (like position:fixed). The sticky value is not supported in IE or Edge 15 and earlier versions. However, for these versions the navbar will inherit default position */
        .navbar {
            overflow: hidden;
            background-color: #333;
            position: sticky;
            position: -webkit-sticky;
            top: 0;
        }

        /* Style the navigation bar links */
        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
            font-family: 'Times New Roman', Times, serif;
        }


        /* Right-aligned link */
        .navbar a.right {
            float: right;
        }

        /* Change color on hover */
        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        /* Active/current link */
        .navbar a.active {
            background-color: #666;
            color: white;
        }

        /* Column container */
        .row {
            display: -ms-flexbox;
            /* IE10 */
            display: flex;
            -ms-flex-wrap: wrap;
            /* IE10 */
            flex-wrap: wrap;
        }

        /* Create two unequal columns that sits next to each other */
        /* Sidebar/left column */
        .side {
            -ms-flex: 30%;
            /* IE10 */
            flex: 30%;
            padding: 10px;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #111;
            overflow-x: hidden;
            padding-top: 40px;
            text-decoration: none;
        }

        .side a {
            padding: 6px 8px 6px 16px;
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
            font-family: 'Times New Roman', Times, serif;
            text-align: center;
        }

        .side a:hover {
            color: #f1f1f1;
        }

        /* Main column */
        .main {
            -ms-flex: 70%;
            /* IE10 */
            flex: 70%;
            background-color: white;
            padding: 20px;
        }

        /* Footer */
        .footer {
            margin: 0px;
            padding: 0.5px;
            text-align: center;
            background-color: #111;
        }

        h6 {
            color: #fff;
            font-family: 'Times New Roman', Times, serif;
        }

        /* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
        @media  screen and (max-width: 700px) {
            .row {
                flex-direction: column;
            }
        }

        /* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
        @media  screen and (max-width: 400px) {
            .navbar a {
                float: none;
                width: 100%;
            }
        }

    </style>
</head>

<body>
    <div class="header">
        <h1>La Cuisine</h1>
    </div>
    <div class="row">
        <div class="side">
            <section>
                <nav>
                    <a href="">London</a>
                    <a href="">Paris</a>
                    <a href="">Tokyo</a>
                </nav>
            </section>
        </div>
        <div class="main">
            <div class="content_user">
                <?php echo $__env->yieldContent('content_user'); ?>
                <br>
            </div>
        </div>
    </div>

    <div class="footer">
        <h6>Guilherme Gonçalves e Lavínia Pedrosa</h6>
    </div>
</body>

</html>
<?php /**PATH /home/ifsp/Documents/Projeto_Filme/La_Cuisine2/resources/views/layout2.blade.php ENDPATH**/ ?>