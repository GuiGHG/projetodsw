@extends('layout2')
@section('content_user')
<style>
    input[type=text] {
        width: 50%;
        color: gray;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type=submit] {
        width: 30%;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    div {
        border-radius: 5px;
        background-color: #f2f2f2;
        padding: 20px;
    }

</style>
<h1>Cria Post</h1>
<form action="/create/post">
        <input type="text" name="texto" placeholder="Digite o texto">
        <input type="text" name="comentario" placeholder="Digite o comentario">
        <input type="text" name="email" placeholder="Digite o email">
        <br>
        <input type="submit" name="submit" value="Enviar">
        @foreach ($createpost as $post)
                          <br>
                          *POST* ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                          <br>
                          {{$post->texto}} 
                          <br>
                          <br>
                          <br>
                          Comentarios do Post Acima:
                          <br>
                          {{$post->comentario}}
                          <a href="{{ route('delete.post', ['id' => $post->id]) }}">Apagar</a>
                          <br>
                          <br>
                @endforeach
</form>

@stop
