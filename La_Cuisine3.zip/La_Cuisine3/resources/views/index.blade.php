@extends('layout')
@section('content')
<style>
    input[type=text] {
        width: 50%;
        color: gray;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    input[type=submit] {
        width: 30%;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    div {
        border-radius: 5px;
        background-color: #f2f2f2;
        padding: 20px;
    }

    

</style>
<h1>La Cuisine</h1>
<form action="/home">
    <input type="text" name="nome" placeholder="Digite o usuario">
    <input type="text" name="senha" placeholder="Digite a senha">
    <br>
    <input type="submit" name="submit" value="Enviar">
    <a href=""><h6>Não tenho Cadastro</h6></a>
    <a href=""><h6>Entrar sem Cadastro</h6></a>
</form>


@stop
